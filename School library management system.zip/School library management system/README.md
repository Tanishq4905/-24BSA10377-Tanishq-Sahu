# School Library Management System (MongoDB Relationships & CRUD)

This project is a backend REST API and Console CLI application designed to demonstrate database connections, CRUD (Create, Read, Update, Delete, Drop) operations, and relationships mapping in MongoDB.

Built using **Python 3.12**, **FastAPI**, and **PyMongo**.

---

## 🌟 Key Features
- **Zero-Setup Support**: Automatically detects if MongoDB is running locally. If not, it falls back to `mongomock` (an in-memory MongoDB mock) so you can run and test everything immediately without installing MongoDB.
- **Relational Mappings in MongoDB**:
  - **One-to-One**: `Student` <-> `StudentProfile` (Addresses & Phones).
  - **One-to-Many / Many-to-One**: `Department` <-> `Staff`/`Students`/`Books` (via foreign keys / references).
  - **Many-to-Many**: `Student` <-> `Book` (via a borrowed list reference `borrowed_by` array on books).
- **Interactive Swagger Documentation**: Generated automatically at `/docs` for testing with a browser or Postman.
- **Interactive CLI Console Application**: Menu-driven interface in terminal for quick operations.

---

## 🛠 Project Structure
```text
mongodb-relations-backend/
├── app/
│   ├── __init__.py
│   ├── database.py   # DB Connection & Collections setup
│   ├── models.py     # Pydantic validation schemas
│   ├── crud.py       # Core MongoDB aggregation ($lookup) & queries
│   └── main.py       # FastAPI REST endpoints
├── .venv/            # Python Virtual Environment
├── requirements.txt  # Dependencies list
├── console_app.py    # Command-line interactive terminal app
└── README.md         # Setup and run guide
```

---

## 🚀 Setup & Installation

### 1. Prerequisite
Ensure **Python 3.12** is installed.

### 2. Activate Virtual Environment & Install Dependencies
Open a terminal (e.g. PowerShell) in the project root directory and run:

```powershell
# Create virtual environment (if not already done)
python -m venv .venv

# Activate virtual environment
.\.venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

---

## 🖥 Run the Interactive Console Application

The console application provides an interactive menu to seed mock data, query entities, perform CRUD, drop collections, and inspect real relationships with tables.

Make sure your virtual environment is active, then run:
```powershell
python console_app.py
```

---

## 🌐 Run the REST API (with Swagger UI)

To run the REST API server:
```powershell
# Make sure virtual environment is active
.\.venv\Scripts\activate

# Start the dev server
uvicorn app.main:app --reload
```
Once started:
- Access the interactive **Swagger UI** at: **[http://localhost:8000/docs](http://localhost:8000/docs)**
- Check database connection details at: **[http://localhost:8000/db-info](http://localhost:8000/db-info)**

You can use the Swagger UI or Postman to test all endpoints.

---

## 📊 Database Relationships Explained

1. **One-to-One (`Student` & `StudentProfile`)**
   - Each `Student` has one `StudentProfile` detailing their address and phone number.
   - Modeled by storing a `student_id` (referencing `students._id`) inside the `student_profiles` collection.
   - When a student is deleted, their profile is also deleted automatically (cascading delete).

2. **One-to-Many / Many-to-One (`Department` & `Staff` / `Student` / `Book`)**
   - A `Department` has multiple staff members, students, and books.
   - Each `Staff`, `Student`, and `Book` document stores a reference `department_id` (referencing `departments._id`).
   - Querying department details performs a `$lookup` aggregation to pull all entities associated with it in a single query.

3. **Many-to-Many (`Student` & `Book`)**
   - A `Student` can borrow multiple books, and a `Book` can be borrowed by multiple students.
   - Modeled using a `borrowed_by` array of `Student` ObjectIds inside the `books` collection.
   - The application provides `/books/{id}/borrow/{student_id}` and `/books/{id}/return/{student_id}` endpoints to append/remove students from this array.
