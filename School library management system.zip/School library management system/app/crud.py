from bson import ObjectId
from bson.errors import InvalidId
from typing import List, Dict, Any, Optional
from app.database import (
    departments_col,
    staff_col,
    students_col,
    student_profiles_col,
    books_col,
)

# --- HELPER FUNCTIONS ---

def to_obj_id(id_str: str) -> ObjectId:
    """Helper to convert string ID to ObjectId, handles invalid IDs."""
    try:
        return ObjectId(id_str)
    except InvalidId:
        raise ValueError(f"Invalid ObjectId format: '{id_str}'")

def serialize_doc(doc: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Converts MongoDB ObjectIds to strings recursively for API compatibility."""
    if doc is None:
        return None
    
    serialized = {}
    for key, value in doc.items():
        if key == "_id":
            serialized["id"] = str(value)
        elif isinstance(value, ObjectId):
            serialized[key] = str(value)
        elif isinstance(value, list):
            serialized[key] = [
                str(item) if isinstance(item, ObjectId) else item 
                for item in value
            ]
        elif isinstance(value, dict):
            serialized[key] = serialize_doc(value)
        else:
            serialized[key] = value
            
    return serialized

def serialize_list(cursor) -> List[Dict[str, Any]]:
    """Serializes a list of MongoDB documents."""
    return [serialize_doc(doc) for doc in cursor if doc]


# --- DEPARTMENT CRUD ---

def create_department(name: str, code: str) -> Dict[str, Any]:
    department = {"name": name, "code": code}
    result = departments_col.insert_one(department)
    department["_id"] = result.inserted_id
    return serialize_doc(department)

def get_department(id_str: str) -> Optional[Dict[str, Any]]:
    doc = departments_col.find_one({"_id": to_obj_id(id_str)})
    return serialize_doc(doc)

def list_departments() -> List[Dict[str, Any]]:
    return serialize_list(departments_col.find())

def update_department(id_str: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    # Remove None values
    clean_data = {k: v for k, v in data.items() if v is not None}
    if not clean_data:
        return get_department(id_str)
        
    result = departments_col.update_one(
        {"_id": to_obj_id(id_str)}, 
        {"$set": clean_data}
    )
    if result.matched_count == 0:
        return None
    return get_department(id_str)

def delete_department(id_str: str) -> bool:
    dept_id = to_obj_id(id_str)
    # Perform a cascade action: update entities associated with this department to hold None or default?
    # For this project, we'll set their department_id to None or delete. Let's set department_id to None.
    staff_col.update_many({"department_id": dept_id}, {"$set": {"department_id": None}})
    students_col.update_many({"department_id": dept_id}, {"$set": {"department_id": None}})
    books_col.update_many({"department_id": dept_id}, {"$set": {"department_id": None}})
    
    result = departments_col.delete_one({"_id": dept_id})
    return result.deleted_count > 0

def drop_departments() -> bool:
    departments_col.drop()
    return True

def get_department_details(id_str: str) -> Optional[Dict[str, Any]]:
    """
    Retrieves a department with its associated Staff, Students, and Books.
    Demonstrates ONE-TO-MANY relationships via MongoDB $lookup (Join).
    """
    dept_id = to_obj_id(id_str)
    
    pipeline = [
        {"$match": {"_id": dept_id}},
        # Lookup staff: join on department_id
        {
            "$lookup": {
                "from": "staff",
                "localField": "_id",
                "foreignField": "department_id",
                "as": "staff"
            }
        },
        # Lookup students: join on department_id
        {
            "$lookup": {
                "from": "students",
                "localField": "_id",
                "foreignField": "department_id",
                "as": "students"
            }
        },
        # Lookup books: join on department_id
        {
            "$lookup": {
                "from": "books",
                "localField": "_id",
                "foreignField": "department_id",
                "as": "books"
            }
        }
    ]
    
    results = list(departments_col.aggregate(pipeline))
    if not results:
        return None
    return serialize_doc(results[0])


# --- STAFF CRUD ---

def create_staff(name: str, role: str, department_id_str: str) -> Dict[str, Any]:
    dept_id = to_obj_id(department_id_str)
    # Check if department exists
    if not departments_col.find_one({"_id": dept_id}):
        raise ValueError(f"Department ID {department_id_str} does not exist.")
        
    staff = {
        "name": name,
        "role": role,
        "department_id": dept_id
    }
    result = staff_col.insert_one(staff)
    staff["_id"] = result.inserted_id
    return serialize_doc(staff)

def get_staff(id_str: str) -> Optional[Dict[str, Any]]:
    doc = staff_col.find_one({"_id": to_obj_id(id_str)})
    return serialize_doc(doc)

def list_staff() -> List[Dict[str, Any]]:
    return serialize_list(staff_col.find())

def update_staff(id_str: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    clean_data = {k: v for k, v in data.items() if v is not None}
    
    if "department_id" in clean_data and clean_data["department_id"] is not None:
        dept_id = to_obj_id(clean_data["department_id"])
        if not departments_col.find_one({"_id": dept_id}):
            raise ValueError(f"Department ID {clean_data['department_id']} does not exist.")
        clean_data["department_id"] = dept_id
        
    if not clean_data:
        return get_staff(id_str)
        
    result = staff_col.update_one({"_id": to_obj_id(id_str)}, {"$set": clean_data})
    if result.matched_count == 0:
        return None
    return get_staff(id_str)

def delete_staff(id_str: str) -> bool:
    result = staff_col.delete_one({"_id": to_obj_id(id_str)})
    return result.deleted_count > 0

def drop_staff() -> bool:
    staff_col.drop()
    return True

def get_staff_details(id_str: str) -> Optional[Dict[str, Any]]:
    """
    Retrieves staff member details including their department.
    Demonstrates MANY-TO-ONE relationship via MongoDB $lookup.
    """
    staff_id = to_obj_id(id_str)
    
    pipeline = [
        {"$match": {"_id": staff_id}},
        {
            "$lookup": {
                "from": "departments",
                "localField": "department_id",
                "foreignField": "_id",
                "as": "department"
            }
        },
        # Unwind the department array to make it a single object
        {
            "$unwind": {
                "path": "$department",
                "preserveNullAndEmptyArrays": True
            }
        }
    ]
    
    results = list(staff_col.aggregate(pipeline))
    if not results:
        return None
    return serialize_doc(results[0])


# --- STUDENT & STUDENT PROFILE (ONE-TO-ONE) CRUD ---

def create_student(name: str, roll_no: str, department_id_str: str, profile_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    dept_id = to_obj_id(department_id_str)
    if not departments_col.find_one({"_id": dept_id}):
        raise ValueError(f"Department ID {department_id_str} does not exist.")
        
    student = {
        "name": name,
        "roll_no": roll_no,
        "department_id": dept_id
    }
    
    result = students_col.insert_one(student)
    student_id = result.inserted_id
    student["_id"] = student_id
    
    # Create Profile if details are passed (One-to-One Relationship)
    if profile_data:
        profile = {
            "student_id": student_id,
            "address": profile_data.get("address"),
            "phone_number": profile_data.get("phone_number")
        }
        student_profiles_col.insert_one(profile)
        student["profile"] = profile
        
    return serialize_doc(student)

def get_student(id_str: str) -> Optional[Dict[str, Any]]:
    doc = students_col.find_one({"_id": to_obj_id(id_str)})
    return serialize_doc(doc)

def list_students() -> List[Dict[str, Any]]:
    return serialize_list(students_col.find())

def update_student(id_str: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    student_id = to_obj_id(id_str)
    
    # Separate Student updates and Profile updates
    student_fields = {}
    for k in ["name", "roll_no", "department_id"]:
        if k in data and data[k] is not None:
            if k == "department_id":
                dept_id = to_obj_id(data[k])
                if not departments_col.find_one({"_id": dept_id}):
                    raise ValueError(f"Department ID {data[k]} does not exist.")
                student_fields[k] = dept_id
            else:
                student_fields[k] = data[k]
                
    if student_fields:
        students_col.update_one({"_id": student_id}, {"$set": student_fields})
        
    # Update profile if provided (One-to-One)
    profile_data = data.get("profile")
    if profile_data:
        clean_profile = {k: v for k, v in profile_data.items() if v is not None}
        if clean_profile:
            student_profiles_col.update_one(
                {"student_id": student_id},
                {"$set": clean_profile},
                upsert=True
            )
            
    return get_student_details(id_str)

def delete_student(id_str: str) -> bool:
    student_id = to_obj_id(id_str)
    
    # 1. Delete associated Student Profile (One-to-One cascade)
    student_profiles_col.delete_many({"student_id": student_id})
    
    # 2. Remove student from any book's borrowed_by list (Many-to-Many update)
    books_col.update_many(
        {"borrowed_by": student_id},
        {"$pull": {"borrowed_by": student_id}}
    )
    
    # 3. Delete student record
    result = students_col.delete_one({"_id": student_id})
    return result.deleted_count > 0

def drop_students() -> bool:
    students_col.drop()
    student_profiles_col.drop()
    return True

def get_student_details(id_str: str) -> Optional[Dict[str, Any]]:
    """
    Retrieves student details:
    1. Joined Department (Many-to-One)
    2. Joined Profile (One-to-One)
    3. Joined Borrowed Books (Many-to-Many)
    """
    student_id = to_obj_id(id_str)
    
    pipeline = [
        {"$match": {"_id": student_id}},
        # Join Department (Many-to-One)
        {
            "$lookup": {
                "from": "departments",
                "localField": "department_id",
                "foreignField": "_id",
                "as": "department"
            }
        },
        {"$unwind": {"path": "$department", "preserveNullAndEmptyArrays": True}},
        # Join Student Profile (One-to-One)
        {
            "$lookup": {
                "from": "student_profiles",
                "localField": "_id",
                "foreignField": "student_id",
                "as": "profile"
            }
        },
        {"$unwind": {"path": "$profile", "preserveNullAndEmptyArrays": True}},
        # Join Borrowed Books (Many-to-Many: book.borrowed_by list contains student_id)
        {
            "$lookup": {
                "from": "books",
                "localField": "_id",
                "foreignField": "borrowed_by",
                "as": "borrowed_books"
            }
        }
    ]
    
    results = list(students_col.aggregate(pipeline))
    if not results:
        return None
    return serialize_doc(results[0])


# --- BOOK CRUD & MANY-TO-MANY RELATIONSHIPS ---

def create_book(title: str, isbn: str, department_id_str: str) -> Dict[str, Any]:
    dept_id = to_obj_id(department_id_str)
    if not departments_col.find_one({"_id": dept_id}):
        raise ValueError(f"Department ID {department_id_str} does not exist.")
        
    book = {
        "title": title,
        "isbn": isbn,
        "department_id": dept_id,
        "borrowed_by": [] # Holds references to Student ObjectIds (Many-to-Many)
    }
    result = books_col.insert_one(book)
    book["_id"] = result.inserted_id
    return serialize_doc(book)

def get_book(id_str: str) -> Optional[Dict[str, Any]]:
    doc = books_col.find_one({"_id": to_obj_id(id_str)})
    return serialize_doc(doc)

def list_books() -> List[Dict[str, Any]]:
    return serialize_list(books_col.find())

def update_book(id_str: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    clean_data = {}
    for k in ["title", "isbn", "department_id", "borrowed_by"]:
        if k in data and data[k] is not None:
            if k == "department_id":
                clean_data[k] = to_obj_id(data[k])
            elif k == "borrowed_by":
                clean_data[k] = [to_obj_id(sid) for sid in data[k]]
            else:
                clean_data[k] = data[k]
                
    if not clean_data:
        return get_book(id_str)
        
    result = books_col.update_one({"_id": to_obj_id(id_str)}, {"$set": clean_data})
    if result.matched_count == 0:
        return None
    return get_book(id_str)

def delete_book(id_str: str) -> bool:
    result = books_col.delete_one({"_id": to_obj_id(id_str)})
    return result.deleted_count > 0

def drop_books() -> bool:
    books_col.drop()
    return True

def borrow_book(book_id_str: str, student_id_str: str) -> Optional[Dict[str, Any]]:
    """
    Borrows a book (adds a student reference to the borrowed_by array).
    Demonstrates MANY-TO-MANY action.
    """
    book_id = to_obj_id(book_id_str)
    student_id = to_obj_id(student_id_str)
    
    # Verify both exist
    if not books_col.find_one({"_id": book_id}):
        raise ValueError(f"Book ID {book_id_str} does not exist.")
    if not students_col.find_one({"_id": student_id}):
        raise ValueError(f"Student ID {student_id_str} does not exist.")
        
    # Add student to book's borrowed_by list (using $addToSet to avoid duplicates)
    books_col.update_one(
        {"_id": book_id},
        {"$addToSet": {"borrowed_by": student_id}}
    )
    return get_book_details(book_id_str)

def return_book(book_id_str: str, student_id_str: str) -> Optional[Dict[str, Any]]:
    """
    Returns a book (removes a student reference from the borrowed_by array).
    Demonstrates MANY-TO-MANY action.
    """
    book_id = to_obj_id(book_id_str)
    student_id = to_obj_id(student_id_str)
    
    # Remove student from book's borrowed_by list
    books_col.update_one(
        {"_id": book_id},
        {"$pull": {"borrowed_by": student_id}}
    )
    return get_book_details(book_id_str)

def get_book_details(id_str: str) -> Optional[Dict[str, Any]]:
    """
    Retrieves book details with department and borrowing students.
    Demonstrates MANY-TO-ONE (Department) and MANY-TO-MANY (Students) relationships.
    """
    book_id = to_obj_id(id_str)
    
    pipeline = [
        {"$match": {"_id": book_id}},
        # Join Department (Many-to-One)
        {
            "$lookup": {
                "from": "departments",
                "localField": "department_id",
                "foreignField": "_id",
                "as": "department"
            }
        },
        {"$unwind": {"path": "$department", "preserveNullAndEmptyArrays": True}},
        # Join Students who borrowed it (Many-to-Many)
        {
            "$lookup": {
                "from": "students",
                "localField": "borrowed_by",
                "foreignField": "_id",
                "as": "borrowed_by_students"
            }
        }
    ]
    
    results = list(books_col.aggregate(pipeline))
    if not results:
        return None
    return serialize_doc(results[0])
