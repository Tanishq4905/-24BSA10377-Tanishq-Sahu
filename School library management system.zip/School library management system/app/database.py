import os
import sys
import logging
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from dotenv import load_dotenv

# Set up logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Load environmental variables
load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "school_db")

client = None
db = None
is_mock = False

try:
    logger.info(f"Attempting to connect to MongoDB at {MONGO_URI}...")
    # Use a short timeout (2 seconds) so it fails fast if MongoDB is not running
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000)
    # Ping the server to check connection
    client.admin.command("ping")
    db = client[DB_NAME]
    logger.info("Successfully connected to the real MongoDB database!")
except (ConnectionFailure, ServerSelectionTimeoutError, Exception) as e:
    logger.warning(
        f"\nCould not connect to MongoDB at {MONGO_URI} (Error: {e}).\n"
        "-> AUTOMATIC FALLBACK: Starting in-memory mock database using 'mongomock' instead.\n"
        "No installation or server start is required. All changes will be in-memory."
    )
    import mongomock
    client = mongomock.MongoClient()
    db = client[DB_NAME]
    is_mock = True

# Collections
departments_col = db["departments"]
staff_col = db["staff"]
students_col = db["students"]
student_profiles_col = db["student_profiles"]
books_col = db["books"]

def get_db_info():
    """Returns database type and URI information."""
    return {
        "is_mock": is_mock,
        "db_type": "In-Memory Mock (mongomock)" if is_mock else "Real MongoDB",
        "uri": MONGO_URI if not is_mock else "in-memory-mock-connection"
    }
