from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from typing import List
from pathlib import Path
from app.database import get_db_info
from app.models import (
    DepartmentCreate,
    DepartmentUpdate,
    DepartmentResponse,
    DepartmentWithRelationsResponse,
    StaffCreate,
    StaffUpdate,
    StaffResponse,
    StaffWithRelationsResponse,
    StudentCreate,
    StudentUpdate,
    StudentResponse,
    StudentWithRelationsResponse,
    BookCreate,
    BookUpdate,
    BookResponse,
    BookWithRelationsResponse,
)
import app.crud as crud

app = FastAPI(
    title="School Library Management API (MongoDB Relationships)",
    description=(
        "This API demonstrates DB connection, CRUD, and table/collection mapping relationships "
        "(One-to-One, One-to-Many, Many-to-One, Many-to-Many) in MongoDB."
    ),
    version="1.0.0",
)

# --- CORS MIDDLEWARE ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- FRONTEND STATIC FILES ---
FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"
if FRONTEND_DIR.exists():
    app.mount("/frontend", StaticFiles(directory=str(FRONTEND_DIR)), name="frontend")

    @app.get("/", include_in_schema=False)
    def serve_frontend():
        return FileResponse(str(FRONTEND_DIR / "index.html"))

# --- SYSTEM ENDPOINTS ---

@app.get("/db-info", tags=["System"])
def get_database_status():
    """Check whether the server is running on a real MongoDB instance or an in-memory mock."""
    return get_db_info()


# --- DEPARTMENT ENDPOINTS ---

@app.post("/departments", response_model=DepartmentResponse, status_code=status.HTTP_201_CREATED, tags=["Departments"])
def create_dept(payload: DepartmentCreate):
    return crud.create_department(payload.name, payload.code)

@app.get("/departments", response_model=List[DepartmentResponse], tags=["Departments"])
def list_depts():
    return crud.list_departments()

@app.get("/departments/{id}", response_model=DepartmentResponse, tags=["Departments"])
def get_dept(id: str):
    try:
        dept = crud.get_department(id)
        if not dept:
            raise HTTPException(status_code=404, detail="Department not found")
        return dept
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/departments/{id}/details", response_model=DepartmentWithRelationsResponse, tags=["Departments"])
def get_dept_details(id: str):
    """Get department details with lists of associated Staff, Students, and Books (One-to-Many)."""
    try:
        details = crud.get_department_details(id)
        if not details:
            raise HTTPException(status_code=404, detail="Department not found")
        return details
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.put("/departments/{id}", response_model=DepartmentResponse, tags=["Departments"])
def update_dept(id: str, payload: DepartmentUpdate):
    try:
        dept = crud.update_department(id, payload.model_dump())
        if not dept:
            raise HTTPException(status_code=404, detail="Department not found")
        return dept
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/departments/{id}", tags=["Departments"])
def delete_dept(id: str):
    try:
        success = crud.delete_department(id)
        if not success:
            raise HTTPException(status_code=404, detail="Department not found")
        return {"detail": "Department deleted successfully and associated references updated"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/departments", tags=["Departments"])
def drop_depts():
    """Drop the departments collection."""
    crud.drop_departments()
    return {"detail": "Departments collection dropped"}


# --- STAFF ENDPOINTS ---

@app.post("/staff", response_model=StaffResponse, status_code=status.HTTP_201_CREATED, tags=["Staff"])
def create_staff_member(payload: StaffCreate):
    try:
        return crud.create_staff(payload.name, payload.role, payload.department_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/staff", response_model=List[StaffResponse], tags=["Staff"])
def list_staff_members():
    return crud.list_staff()

@app.get("/staff/{id}", response_model=StaffResponse, tags=["Staff"])
def get_staff_member(id: str):
    try:
        staff = crud.get_staff(id)
        if not staff:
            raise HTTPException(status_code=404, detail="Staff member not found")
        return staff
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/staff/{id}/details", response_model=StaffWithRelationsResponse, tags=["Staff"])
def get_staff_member_details(id: str):
    """Get staff member details populated with their Department info (Many-to-One)."""
    try:
        details = crud.get_staff_details(id)
        if not details:
            raise HTTPException(status_code=404, detail="Staff member not found")
        return details
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.put("/staff/{id}", response_model=StaffResponse, tags=["Staff"])
def update_staff_member(id: str, payload: StaffUpdate):
    try:
        staff = crud.update_staff(id, payload.model_dump())
        if not staff:
            raise HTTPException(status_code=404, detail="Staff member not found")
        return staff
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/staff/{id}", tags=["Staff"])
def delete_staff_member(id: str):
    try:
        success = crud.delete_staff(id)
        if not success:
            raise HTTPException(status_code=404, detail="Staff member not found")
        return {"detail": "Staff member deleted successfully"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/staff", tags=["Staff"])
def drop_staff_col():
    """Drop the staff collection."""
    crud.drop_staff()
    return {"detail": "Staff collection dropped"}


# --- STUDENT ENDPOINTS ---

@app.post("/students", response_model=StudentResponse, status_code=status.HTTP_201_CREATED, tags=["Students"])
def create_stud(payload: StudentCreate):
    try:
        profile_dict = payload.profile.model_dump() if payload.profile else None
        return crud.create_student(payload.name, payload.roll_no, payload.department_id, profile_dict)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/students", response_model=List[StudentResponse], tags=["Students"])
def list_studs():
    return crud.list_students()

@app.get("/students/{id}", response_model=StudentResponse, tags=["Students"])
def get_stud(id: str):
    try:
        stud = crud.get_student(id)
        if not stud:
            raise HTTPException(status_code=404, detail="Student not found")
        return stud
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/students/{id}/details", response_model=StudentWithRelationsResponse, tags=["Students"])
def get_stud_details(id: str):
    """Get student details with joined Department (Many-to-One), Profile (One-to-One), and borrowed Books (Many-to-Many)."""
    try:
        details = crud.get_student_details(id)
        if not details:
            raise HTTPException(status_code=404, detail="Student not found")
        return details
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.put("/students/{id}", response_model=StudentWithRelationsResponse, tags=["Students"])
def update_stud(id: str, payload: StudentUpdate):
    try:
        stud = crud.update_student(id, payload.model_dump())
        if not stud:
            raise HTTPException(status_code=404, detail="Student not found")
        return stud
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/students/{id}", tags=["Students"])
def delete_stud(id: str):
    try:
        success = crud.delete_student(id)
        if not success:
            raise HTTPException(status_code=404, detail="Student not found")
        return {"detail": "Student and associated profile deleted successfully, and library records updated"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/students", tags=["Students"])
def drop_students_col():
    """Drop the students and student profiles collections."""
    crud.drop_students()
    return {"detail": "Students and Student Profiles collections dropped"}


# --- BOOK ENDPOINTS ---

@app.post("/books", response_model=BookResponse, status_code=status.HTTP_201_CREATED, tags=["Books"])
def create_bk(payload: BookCreate):
    try:
        return crud.create_book(payload.title, payload.isbn, payload.department_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/books", response_model=List[BookResponse], tags=["Books"])
def list_bks():
    return crud.list_books()

@app.get("/books/{id}", response_model=BookResponse, tags=["Books"])
def get_bk(id: str):
    try:
        bk = crud.get_book(id)
        if not bk:
            raise HTTPException(status_code=404, detail="Book not found")
        return bk
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/books/{id}/details", response_model=BookWithRelationsResponse, tags=["Books"])
def get_bk_details(id: str):
    """Get book details with joined Department (Many-to-One) and borrowing Students (Many-to-Many)."""
    try:
        details = crud.get_book_details(id)
        if not details:
            raise HTTPException(status_code=404, detail="Book not found")
        return details
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.put("/books/{id}", response_model=BookResponse, tags=["Books"])
def update_bk(id: str, payload: BookUpdate):
    try:
        bk = crud.update_book(id, payload.model_dump())
        if not bk:
            raise HTTPException(status_code=404, detail="Book not found")
        return bk
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/books/{id}", tags=["Books"])
def delete_bk(id: str):
    try:
        success = crud.delete_book(id)
        if not success:
            raise HTTPException(status_code=404, detail="Book not found")
        return {"detail": "Book deleted successfully"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/books", tags=["Books"])
def drop_books_col():
    """Drop the books collection."""
    crud.drop_books()
    return {"detail": "Books collection dropped"}

@app.post("/books/{id}/borrow/{student_id}", response_model=BookWithRelationsResponse, tags=["Books / Borrowing"])
def borrow_book_endpoint(id: str, student_id: str):
    """Borrow a book (adds student reference to book's borrowed_by array). Demonstrates MANY-TO-MANY mapping."""
    try:
        updated = crud.borrow_book(id, student_id)
        if not updated:
            raise HTTPException(status_code=404, detail="Book or Student not found")
        return updated
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/books/{id}/return/{student_id}", response_model=BookWithRelationsResponse, tags=["Books / Borrowing"])
def return_book_endpoint(id: str, student_id: str):
    """Return a book (removes student reference from book's borrowed_by array). Demonstrates MANY-TO-MANY mapping."""
    try:
        updated = crud.return_book(id, student_id)
        if not updated:
            raise HTTPException(status_code=404, detail="Book or Student not found")
        return updated
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
