from pydantic import BaseModel, Field
from typing import List, Optional

# --- HELPER BASE MODELS ---

class MongoBaseModel(BaseModel):
    id: str = Field(..., description="String representation of MongoDB ObjectId")

# --- DEPARTMENT MODELS ---

class DepartmentBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    code: str = Field(..., min_length=2, max_length=10)

class DepartmentCreate(DepartmentBase):
    pass

class DepartmentUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    code: Optional[str] = Field(None, min_length=2, max_length=10)

class DepartmentResponse(DepartmentBase, MongoBaseModel):
    pass

# --- STAFF MODELS ---

class StaffBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    role: str = Field(..., min_length=2, max_length=50, description="e.g. Professor, Admin, Assistant")
    department_id: str = Field(..., description="ID of the Department the staff member belongs to")

class StaffCreate(StaffBase):
    pass

class StaffUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    role: Optional[str] = Field(None, min_length=2, max_length=50)
    department_id: Optional[str] = None

class StaffResponse(StaffBase, MongoBaseModel):
    pass

class StaffWithRelationsResponse(MongoBaseModel):
    name: str
    role: str
    department: Optional[DepartmentResponse] = None

# --- STUDENT PROFILE MODELS (One-to-One Relation with Student) ---

class StudentProfileBase(BaseModel):
    address: str = Field(..., min_length=5, max_length=200)
    phone_number: str = Field(..., min_length=10, max_length=15)

class StudentProfileCreate(StudentProfileBase):
    student_id: str

class StudentProfileUpdate(BaseModel):
    address: Optional[str] = Field(None, min_length=5, max_length=200)
    phone_number: Optional[str] = Field(None, min_length=10, max_length=15)

class StudentProfileResponse(StudentProfileBase, MongoBaseModel):
    student_id: str

# --- STUDENT MODELS ---

class StudentBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    roll_no: str = Field(..., min_length=2, max_length=20)
    department_id: str = Field(..., description="ID of the Department the student belongs to")

class StudentCreate(StudentBase):
    # Optional profile info during creation to create both student & profile together easily
    profile: Optional[StudentProfileBase] = None

class StudentUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    roll_no: Optional[str] = Field(None, min_length=2, max_length=20)
    department_id: Optional[str] = None
    profile: Optional[StudentProfileUpdate] = None

class StudentResponse(StudentBase, MongoBaseModel):
    pass

# --- BOOK MODELS ---

class BookBase(BaseModel):
    title: str = Field(..., min_length=2, max_length=150)
    isbn: str = Field(..., min_length=10, max_length=17)
    department_id: str = Field(..., description="ID of the Department that owns the book")

class BookCreate(BookBase):
    pass

class BookUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=2, max_length=150)
    isbn: Optional[str] = Field(None, min_length=10, max_length=17)
    department_id: Optional[str] = None
    borrowed_by: Optional[List[str]] = None

class BookResponse(BookBase, MongoBaseModel):
    borrowed_by: List[str] = Field(default_factory=list, description="List of Student IDs borrowing this book")

# --- DETAILED RELATION MODELS ---

class BookWithRelationsResponse(MongoBaseModel):
    title: str
    isbn: str
    department: Optional[DepartmentResponse] = None
    borrowed_by_students: List[StudentResponse] = Field(default_factory=list)

class StudentWithRelationsResponse(MongoBaseModel):
    name: str
    roll_no: str
    department: Optional[DepartmentResponse] = None
    profile: Optional[StudentProfileBase] = None
    borrowed_books: List[BookResponse] = Field(default_factory=list)

class DepartmentWithRelationsResponse(MongoBaseModel):
    name: str
    code: str
    staff: List[StaffResponse] = Field(default_factory=list)
    students: List[StudentResponse] = Field(default_factory=list)
    books: List[BookResponse] = Field(default_factory=list)
