import os
import sys
from bson import ObjectId

# Ensure app package is in path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.database import get_db_info
import app.crud as crud

# ANSI color codes for premium console formatting
RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[32m"
BLUE = "\033[34m"
CYAN = "\033[36m"
YELLOW = "\033[33m"
RED = "\033[31m"
MAGENTA = "\033[35m"

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def print_header(title):
    print("\n" + "=" * 60)
    print(f"| {BOLD}{CYAN}{title.center(56)}{RESET} |")
    print("=" * 60)

def print_menu_option(num, text):
    print(f"  [{BOLD}{GREEN}{num}{RESET}] {text}")

def press_enter_to_continue():
    input(f"\n{YELLOW}Press Enter to return to menu...{RESET}")

def view_connection_info():
    info = get_db_info()
    print_header("DATABASE CONNECTION STATUS")
    print(f"  {BOLD}Connection Type:{RESET} {GREEN if not info['is_mock'] else YELLOW}{info['db_type']}{RESET}")
    print(f"  {BOLD}Connection URI:{RESET}  {info['uri']}")
    print("-" * 60)
    if info["is_mock"]:
        print(f"  {YELLOW}Note: Running in fallback mode using mongomock in-memory DB.{RESET}")
        print("  All operations will work, but data is not persistent across runs.")
    else:
        print(f"  {GREEN}Connected to live MongoDB server. Data is persistent.{RESET}")
    press_enter_to_continue()

def insert_sample_data():
    print_header("INSERTING SAMPLE DATA")
    try:
        # 1. Create Department
        print(f"-> Creating Departments...")
        cs_dept = crud.create_department("Computer Science & Engineering", "CSE")
        math_dept = crud.create_department("Mathematics & Statistics", "MATH")
        
        # 2. Create Staff
        print(f"-> Inserting Staff (Many-to-One)...")
        crud.create_staff("Dr. Alan Turing", "Professor", cs_dept["id"])
        crud.create_staff("Dr. Ada Lovelace", "Associate Professor", cs_dept["id"])
        crud.create_staff("Dr. Carl Gauss", "Professor", math_dept["id"])
        
        # 3. Create Students (with Profile One-to-One relationship)
        print(f"-> Inserting Students (One-to-One)...")
        john = crud.create_student(
            "John Doe", "CSE-101", cs_dept["id"],
            {"address": "123 Turing Way, Silicon Valley", "phone_number": "555-019-2834"}
        )
        jane = crud.create_student(
            "Jane Smith", "MATH-302", math_dept["id"],
            {"address": "456 Fibonacci Blvd, Pi Town", "phone_number": "555-014-9988"}
        )
        
        # 4. Create Books (Many-to-One & Many-to-Many preparation)
        print(f"-> Inserting Books...")
        book1 = crud.create_book("Introduction to Algorithms", "978-0262033848", cs_dept["id"])
        book2 = crud.create_book("Linear Algebra and Its Applications", "978-0321385178", math_dept["id"])
        book3 = crud.create_book("A Brief History of Time", "978-0553380163", cs_dept["id"])
        
        # 5. Borrow Books (Many-to-Many Relationship Mappings)
        print(f"-> Simulating Library Borrowing (Many-to-Many)...")
        crud.borrow_book(book1["id"], john["id"])
        crud.borrow_book(book3["id"], john["id"])
        crud.borrow_book(book2["id"], jane["id"])
        crud.borrow_book(book3["id"], jane["id"]) # Book 3 borrowed by both (historically/concurrently)

        print(f"\n{GREEN}{BOLD}[OK] Sample data created successfully!{RESET}")
        print("  - 2 Departments created")
        print("  - 3 Staff members mapped to Departments (Many-to-One)")
        print("  - 2 Students with Profiles mapped (One-to-One)")
        print("  - 3 Books mapped to Departments (Many-to-One)")
        print("  - Mapped books to students via borrowing (Many-to-Many)")
    except Exception as e:
        print(f"{RED}Error inserting sample data: {e}{RESET}")
    press_enter_to_continue()

def create_entity():
    while True:
        clear_screen()
        print_header("CREATE (INSERT) ENTITY")
        print_menu_option(1, "Create Department")
        print_menu_option(2, "Create Staff")
        print_menu_option(3, "Create Student (with Profile)")
        print_menu_option(4, "Create Book")
        print_menu_option(5, "Back to Main Menu")
        
        choice = input(f"\n{BOLD}Select an entity to create (1-5): {RESET}").strip()
        if choice == "5":
            break
            
        try:
            if choice == "1":
                name = input("Enter Department Name: ").strip()
                code = input("Enter Department Code (e.g. CSE): ").strip()
                if name and code:
                    dept = crud.create_department(name, code)
                    print(f"\n{GREEN}[OK] Created Department: {dept['name']} (ID: {dept['id']}){RESET}")
                else:
                    print(f"{RED}Inputs cannot be empty.{RESET}")
                    
            elif choice == "2":
                depts = crud.list_departments()
                if not depts:
                    print(f"{RED}Please create a department first!{RESET}")
                    press_enter_to_continue()
                    continue
                print("\nAvailable Departments:")
                for d in depts:
                    print(f"  - [{d['id']}] {d['name']} ({d['code']})")
                dept_id = input("\nEnter Department ID: ").strip()
                name = input("Enter Staff Name: ").strip()
                role = input("Enter Staff Role (e.g. Professor): ").strip()
                if name and role and dept_id:
                    staff = crud.create_staff(name, role, dept_id)
                    print(f"\n{GREEN}[OK] Created Staff: {staff['name']} - {staff['role']} (ID: {staff['id']}){RESET}")
                else:
                    print(f"{RED}Inputs cannot be empty.{RESET}")
                    
            elif choice == "3":
                depts = crud.list_departments()
                if not depts:
                    print(f"{RED}Please create a department first!{RESET}")
                    press_enter_to_continue()
                    continue
                print("\nAvailable Departments:")
                for d in depts:
                    print(f"  - [{d['id']}] {d['name']} ({d['code']})")
                dept_id = input("\nEnter Department ID: ").strip()
                name = input("Enter Student Name: ").strip()
                roll_no = input("Enter Roll No: ").strip()
                address = input("Enter Student Address (for Profile): ").strip()
                phone = input("Enter Phone Number: ").strip()
                if name and roll_no and dept_id and address and phone:
                    stud = crud.create_student(name, roll_no, dept_id, {"address": address, "phone_number": phone})
                    print(f"\n{GREEN}[OK] Created Student: {stud['name']} & associated Profile (ID: {stud['id']}){RESET}")
                else:
                    print(f"{RED}Inputs cannot be empty.{RESET}")
                    
            elif choice == "4":
                depts = crud.list_departments()
                if not depts:
                    print(f"{RED}Please create a department first!{RESET}")
                    press_enter_to_continue()
                    continue
                print("\nAvailable Departments:")
                for d in depts:
                    print(f"  - [{d['id']}] {d['name']} ({d['code']})")
                dept_id = input("\nEnter Department ID: ").strip()
                title = input("Enter Book Title: ").strip()
                isbn = input("Enter ISBN: ").strip()
                if title and isbn and dept_id:
                    bk = crud.create_book(title, isbn, dept_id)
                    print(f"\n{GREEN}[OK] Created Book: {bk['title']} (ID: {bk['id']}){RESET}")
                else:
                    print(f"{RED}Inputs cannot be empty.{RESET}")
            else:
                print(f"{RED}Invalid choice.{RESET}")
        except Exception as e:
            print(f"\n{RED}Error: {e}{RESET}")
        press_enter_to_continue()

def view_entities():
    while True:
        clear_screen()
        print_header("READ (VIEW / QUERY) ENTITIES")
        print_menu_option(1, "List Departments (with counts)")
        print_menu_option(2, "List Staff with Departments (Many-to-One)")
        print_menu_option(3, "List Students with Profiles (One-to-One) & Borrowed Books (Many-to-Many)")
        print_menu_option(4, "List Books with borrowing details (Many-to-Many)")
        print_menu_option(5, "View Full Department Details (One-to-Many details)")
        print_menu_option(6, "Back to Main Menu")
        
        choice = input(f"\n{BOLD}Select an option (1-6): {RESET}").strip()
        if choice == "6":
            break
            
        try:
            if choice == "1":
                depts = crud.list_departments()
                print("\n" + "-"*60)
                print(f"{BOLD}{'ID':<25} | {'CODE':<6} | {'NAME':<25}{RESET}")
                print("-"*60)
                for d in depts:
                    print(f"{d['id']:<25} | {d['code']:<6} | {d['name']:<25}")
                    
            elif choice == "2":
                staff_list = crud.list_staff()
                print("\n" + "-"*60)
                print(f"{BOLD}{'NAME':<20} | {'ROLE':<15} | {'DEPARTMENT':<20}{RESET}")
                print("-"*60)
                for s in staff_list:
                    details = crud.get_staff_details(s["id"])
                    dept_name = details.get("department", {}).get("name", "N/A") if details else "N/A"
                    print(f"{s['name']:<20} | {s['role']:<15} | {dept_name:<20}")
                    
            elif choice == "3":
                students = crud.list_students()
                for s in students:
                    details = crud.get_student_details(s["id"])
                    if not details:
                        continue
                    print("\n" + "="*50)
                    print(f"{BOLD}Student:{RESET} {GREEN}{details['name']}{RESET} (Roll: {details['roll_no']})")
                    print(f"  {BOLD}ID:{RESET} {details['id']}")
                    dept_name = details.get("department", {}).get("name", "N/A")
                    print(f"  {BOLD}Department:{RESET} {dept_name}")
                    
                    # One-to-One profile relation
                    profile = details.get("profile", {})
                    if profile:
                        print(f"  {BOLD}Profile (One-to-One):{RESET}")
                        print(f"    - Phone: {profile.get('phone_number')}")
                        print(f"    - Address: {profile.get('address')}")
                    else:
                        print(f"  {BOLD}Profile:{RESET} None")
                        
                    # Many-to-Many books relation
                    borrowed = details.get("borrowed_books", [])
                    print(f"  {BOLD}Borrowed Books (Many-to-Many):{RESET}")
                    if borrowed:
                        for b in borrowed:
                            print(f"    - {b['title']} (ISBN: {b['isbn']})")
                    else:
                        print("    - None")
                        
            elif choice == "4":
                books = crud.list_books()
                print("\n" + "-"*60)
                print(f"{BOLD}{'BOOK TITLE':<25} | {'ISBN':<15} | {'BORROWED BY COUNT'}{RESET}")
                print("-"*60)
                for b in books:
                    details = crud.get_book_details(b["id"])
                    borrowers = details.get("borrowed_by_students", []) if details else []
                    names = ", ".join([s["name"] for s in borrowers]) if borrowers else "None"
                    print(f"{b['title']:<25} | {b['isbn']:<15} | {len(borrowers)} ({names})")
                    
            elif choice == "5":
                depts = crud.list_departments()
                if not depts:
                    print(f"{RED}No departments found.{RESET}")
                    press_enter_to_continue()
                    continue
                print("\nAvailable Departments:")
                for d in depts:
                    print(f"  - [{d['id']}] {d['name']} ({d['code']})")
                dept_id = input("\nEnter Department ID for details: ").strip()
                details = crud.get_department_details(dept_id)
                if not details:
                    print(f"{RED}Department not found.{RESET}")
                else:
                    print("\n" + "="*60)
                    print(f"{BOLD}Department Details (One-to-Many Mapping){RESET}")
                    print(f"Name: {details['name']} ({details['code']})")
                    print("="*60)
                    
                    print(f"\n{BOLD}Associated Staff:{RESET}")
                    staff_m = details.get("staff", [])
                    if staff_m:
                        for s in staff_m:
                            print(f"  - {s['name']} ({s['role']})")
                    else:
                        print("  (None)")
                        
                    print(f"\n{BOLD}Associated Students:{RESET}")
                    studs = details.get("students", [])
                    if studs:
                        for st in studs:
                            print(f"  - {st['name']} (Roll: {st['roll_no']})")
                    else:
                        print("  (None)")
                        
                    print(f"\n{BOLD}Owned Library Books:{RESET}")
                    bks = details.get("books", [])
                    if bks:
                        for bk in bks:
                            print(f"  - {bk['title']} (ISBN: {bk['isbn']})")
                    else:
                        print("  (None)")
            else:
                print(f"{RED}Invalid choice.{RESET}")
        except Exception as e:
            print(f"\n{RED}Error: {e}{RESET}")
        press_enter_to_continue()

def update_entity():
    clear_screen()
    print_header("UPDATE ENTITY")
    print_menu_option(1, "Update Student (Name, Roll, Profile)")
    print_menu_option(2, "Manage Book Borrowing (Borrow/Return Many-to-Many)")
    print_menu_option(3, "Back to Main Menu")
    
    choice = input(f"\n{BOLD}Select an option (1-3): {RESET}").strip()
    if choice == "3":
        return
        
    try:
        if choice == "1":
            students = crud.list_students()
            if not students:
                print(f"{RED}No students found.{RESET}")
                press_enter_to_continue()
                return
            for s in students:
                print(f"  - [{s['id']}] {s['name']} (Roll: {s['roll_no']})")
            student_id = input("\nEnter Student ID: ").strip()
            
            # Check student details first
            existing = crud.get_student_details(student_id)
            if not existing:
                print(f"{RED}Student not found.{RESET}")
                press_enter_to_continue()
                return
                
            print(f"\n{BOLD}Leave fields blank to keep current values.{RESET}")
            name = input(f"New Name [{existing['name']}]: ").strip() or None
            roll_no = input(f"New Roll No [{existing['roll_no']}]: ").strip() or None
            
            profile = existing.get("profile", {}) or {}
            address = input(f"New Address [{profile.get('address', 'None')}]: ").strip() or None
            phone = input(f"New Phone [{profile.get('phone_number', 'None')}]: ").strip() or None
            
            update_data = {}
            if name: update_data["name"] = name
            if roll_no: update_data["roll_no"] = roll_no
            
            if address or phone:
                update_data["profile"] = {
                    "address": address or profile.get("address"),
                    "phone_number": phone or profile.get("phone_number")
                }
                
            updated = crud.update_student(student_id, update_data)
            print(f"\n{GREEN}[OK] Student details updated!{RESET}")
            
        elif choice == "2":
            books = crud.list_books()
            students = crud.list_students()
            if not books or not students:
                print(f"{RED}Books and Students must exist to borrow/return.{RESET}")
                press_enter_to_continue()
                return
                
            print("\nAvailable Books:")
            for b in books:
                print(f"  - [{b['id']}] {b['title']}")
            book_id = input("\nEnter Book ID: ").strip()
            
            print("\nAvailable Students:")
            for s in students:
                print(f"  - [{s['id']}] {s['name']}")
            student_id = input("\nEnter Student ID: ").strip()
            
            action = input("\nDo you want to [B]orrow or [R]eturn this book? (B/R): ").strip().upper()
            if action == "B":
                crud.borrow_book(book_id, student_id)
                print(f"\n{GREEN}[OK] Book borrowed successfully!{RESET}")
            elif action == "R":
                crud.return_book(book_id, student_id)
                print(f"\n{GREEN}[OK] Book returned successfully!{RESET}")
            else:
                print(f"{RED}Invalid action.{RESET}")
    except Exception as e:
        print(f"\n{RED}Error: {e}{RESET}")
    press_enter_to_continue()

def delete_entity():
    clear_screen()
    print_header("DELETE ENTITY")
    print_menu_option(1, "Delete Department (Cascade null)")
    print_menu_option(2, "Delete Staff")
    print_menu_option(3, "Delete Student (Cascade Profile & Borrow links)")
    print_menu_option(4, "Delete Book")
    print_menu_option(5, "Back to Main Menu")
    
    choice = input(f"\n{BOLD}Select an option (1-5): {RESET}").strip()
    if choice == "5":
        return
        
    try:
        if choice == "1":
            depts = crud.list_departments()
            for d in depts:
                print(f"  - [{d['id']}] {d['name']}")
            dept_id = input("\nEnter Department ID to delete: ").strip()
            if crud.delete_department(dept_id):
                print(f"\n{GREEN}[OK] Department deleted successfully and associations cleared!{RESET}")
            else:
                print(f"{RED}Department not found.{RESET}")
                
        elif choice == "2":
            staff = crud.list_staff()
            for s in staff:
                print(f"  - [{s['id']}] {s['name']} ({s['role']})")
            staff_id = input("\nEnter Staff ID to delete: ").strip()
            if crud.delete_staff(staff_id):
                print(f"\n{GREEN}[OK] Staff member deleted successfully!{RESET}")
            else:
                print(f"{RED}Staff member not found.{RESET}")
                
        elif choice == "3":
            students = crud.list_students()
            for s in students:
                print(f"  - [{s['id']}] {s['name']}")
            student_id = input("\nEnter Student ID to delete: ").strip()
            if crud.delete_student(student_id):
                print(f"\n{GREEN}[OK] Student, associated Profile, and Borrowing links deleted!{RESET}")
            else:
                print(f"{RED}Student not found.{RESET}")
                
        elif choice == "4":
            books = crud.list_books()
            for b in books:
                print(f"  - [{b['id']}] {b['title']}")
            book_id = input("\nEnter Book ID to delete: ").strip()
            if crud.delete_book(book_id):
                print(f"\n{GREEN}[OK] Book deleted successfully!{RESET}")
            else:
                print(f"{RED}Book not found.{RESET}")
    except Exception as e:
        print(f"\n{RED}Error: {e}{RESET}")
    press_enter_to_continue()

def drop_collections():
    print_header("DROP COLLECTIONS (TABLES)")
    print(f"{RED}{BOLD}WARNING: This will drop collections and clear ALL data.{RESET}")
    print_menu_option(1, "Drop Departments")
    print_menu_option(2, "Drop Staff")
    print_menu_option(3, "Drop Students (and Profiles)")
    print_menu_option(4, "Drop Books")
    print_menu_option(5, "Back to Main Menu")
    
    choice = input(f"\n{BOLD}Select collection to drop (1-5): {RESET}").strip()
    if choice == "5":
        return
        
    confirm = input(f"{RED}Are you absolutely sure you want to delete this collection? (y/n): {RESET}").strip().lower()
    if confirm != "y":
        print("Operation cancelled.")
        press_enter_to_continue()
        return
        
    try:
        if choice == "1":
            crud.drop_departments()
            print(f"\n{GREEN}[OK] Departments collection dropped.{RESET}")
        elif choice == "2":
            crud.drop_staff()
            print(f"\n{GREEN}[OK] Staff collection dropped.{RESET}")
        elif choice == "3":
            crud.drop_students()
            print(f"\n{GREEN}[OK] Students and profiles collections dropped.{RESET}")
        elif choice == "4":
            crud.drop_books()
            print(f"\n{GREEN}[OK] Books collection dropped.{RESET}")
        else:
            print(f"{RED}Invalid option.{RESET}")
    except Exception as e:
        print(f"\n{RED}Error: {e}{RESET}")
    press_enter_to_continue()

def main():
    # ANSI initialization for Windows compatibility
    if os.name == "nt":
        os.system("")
        
    while True:
        clear_screen()
        print("\n" + "=" * 60)
        print(f"| {BOLD}{GREEN}SCHOOL LIBRARY MANAGEMENT SYSTEM (MONGODB RELATIONSHIPS){RESET} |")
        print("=" * 60)
        
        info = get_db_info()
        db_label = f"[{info['db_type']}]"
        print(f"  Connection: {YELLOW if info['is_mock'] else GREEN}{db_label}{RESET}")
        print("-" * 60)
        
        print_menu_option(1, "Check Database Connection details")
        print_menu_option(2, "Seed / Insert Sample Data (Sets up all mappings)")
        print_menu_option(3, "Create / Insert Entity (Dept, Staff, Student, Book)")
        print_menu_option(4, "Read / View Entities & Relationship Mappings")
        print_menu_option(5, "Update Entities & Book Borrowing (Many-to-Many)")
        print_menu_option(6, "Delete Entities")
        print_menu_option(7, "Drop Collections (Clear Tables)")
        print_menu_option(8, "Exit")
        
        choice = input(f"\n{BOLD}Choose an option (1-8): {RESET}").strip()
        
        if choice == "1":
            view_connection_info()
        elif choice == "2":
            insert_sample_data()
        elif choice == "3":
            create_entity()
        elif choice == "4":
            view_entities()
        elif choice == "5":
            update_entity()
        elif choice == "6":
            delete_entity()
        elif choice == "7":
            drop_collections()
        elif choice == "8":
            print(f"\n{CYAN}Thank you for using the application! Goodbye.{RESET}\n")
            break
        else:
            print(f"\n{RED}Invalid choice, try again.{RESET}")
            press_enter_to_continue()

if __name__ == "__main__":
    main()
