/* eslint-disable */
'use strict';

// ============================================================
// CONFIG
// ============================================================
const API_BASE = window.location.origin;

// ============================================================
// STATE
// ============================================================
const state = {
  departments: [],
  staff: [],
  students: [],
  books: [],
  currentView: 'dashboard',
};

// ============================================================
// UTILITY HELPERS
// ============================================================

async function api(method, path, body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${API_BASE}${path}`, opts);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

function toast(msg, type = 'info') {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
  el.innerHTML = `<span>${icon}</span><span>${msg}</span>`;
  container.appendChild(el);
  setTimeout(() => {
    el.style.animation = 'slideOutRight 0.3s ease forwards';
    setTimeout(() => el.remove(), 300);
  }, 3500);
}

function shortId(id) {
  return id ? `…${id.slice(-8)}` : '—';
}

function getDeptName(deptId) {
  const dept = state.departments.find(d => d.id === deptId);
  return dept ? dept.name : deptId ? shortId(deptId) : '—';
}

function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ============================================================
// NAVIGATION
// ============================================================

function navigate(view) {
  state.currentView = view;
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  const navEl = document.getElementById(`nav-${view}`);
  if (navEl) navEl.classList.add('active');
  const viewEl = document.getElementById(`view-${view}`);
  if (viewEl) viewEl.classList.add('active');

  const labels = { dashboard: 'Dashboard', departments: 'Departments', staff: 'Staff', students: 'Students', books: 'Books', borrowing: 'Borrowing' };
  document.getElementById('breadcrumb').textContent = labels[view] || view;

  if (view === 'departments') loadDepartments();
  if (view === 'staff') loadStaff();
  if (view === 'students') loadStudents();
  if (view === 'books') loadBooks();
  if (view === 'borrowing') refreshBorrowingSelects();
}

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => navigate(btn.dataset.view));
});

document.getElementById('menu-btn').addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('collapsed');
});

// ============================================================
// DB STATUS CHECK
// ============================================================

async function checkDbStatus() {
  try {
    const data = await api('GET', '/db-info');
    const dot = document.getElementById('status-dot');
    const text = document.getElementById('status-text');
    dot.className = 'status-dot online';
    text.textContent = data.db_type || 'Connected';
  } catch {
    const dot = document.getElementById('status-dot');
    const text = document.getElementById('status-text');
    dot.className = 'status-dot offline';
    text.textContent = 'Disconnected';
  }
}

// ============================================================
// LOAD ALL DATA (Dashboard + Badges)
// ============================================================

async function loadAllData() {
  const btn = document.getElementById('global-refresh');
  btn.classList.add('spinning');
  try {
    const [depts, staff, students, books] = await Promise.allSettled([
      api('GET', '/departments'),
      api('GET', '/staff'),
      api('GET', '/students'),
      api('GET', '/books'),
    ]);
    if (depts.status === 'fulfilled')    state.departments = depts.value || [];
    if (staff.status === 'fulfilled')    state.staff       = staff.value || [];
    if (students.status === 'fulfilled') state.students    = students.value || [];
    if (books.status === 'fulfilled')    state.books       = books.value || [];

    // Update dashboard stats
    document.getElementById('stat-departments').textContent = state.departments.length;
    document.getElementById('stat-staff').textContent       = state.staff.length;
    document.getElementById('stat-students').textContent    = state.students.length;
    document.getElementById('stat-books').textContent       = state.books.length;

    // Update badges
    document.getElementById('badge-departments').textContent = state.departments.length;
    document.getElementById('badge-staff').textContent       = state.staff.length;
    document.getElementById('badge-students').textContent    = state.students.length;
    document.getElementById('badge-books').textContent       = state.books.length;

    // Re-render current view
    if (state.currentView === 'departments') renderDepartments();
    if (state.currentView === 'staff')       renderStaff();
    if (state.currentView === 'students')    renderStudents();
    if (state.currentView === 'books')       renderBooks();
    if (state.currentView === 'borrowing')   refreshBorrowingSelects();
  } finally {
    btn.classList.remove('spinning');
  }
}

document.getElementById('global-refresh').addEventListener('click', loadAllData);

// ============================================================
// MODAL SYSTEM
// ============================================================

let modalSubmitFn = null;

function openModal(title, bodyHtml, submitLabel, submitFn) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-submit').textContent = submitLabel;
  modalSubmitFn = submitFn;
  document.getElementById('modal-overlay').classList.add('open');
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  modalSubmitFn = null;
}

document.getElementById('modal-close').addEventListener('click', closeModal);
document.getElementById('modal-cancel').addEventListener('click', closeModal);
document.getElementById('modal-overlay').addEventListener('click', e => {
  if (e.target === document.getElementById('modal-overlay')) closeModal();
});

document.getElementById('modal-submit').addEventListener('click', async () => {
  if (!modalSubmitFn) return;
  const btn = document.getElementById('modal-submit');
  btn.disabled = true;
  btn.innerHTML = '<div class="spinner"></div>';
  try {
    await modalSubmitFn();
    closeModal();
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = btn.getAttribute('data-label') || 'Save';
  }
});

// ============================================================
// DRAWER SYSTEM
// ============================================================

function openDrawer(title, bodyHtml) {
  document.getElementById('drawer-title').textContent = title;
  document.getElementById('drawer-body').innerHTML = bodyHtml;
  document.getElementById('drawer-overlay').classList.add('open');
}

function closeDrawer() {
  document.getElementById('drawer-overlay').classList.remove('open');
}

document.getElementById('drawer-close').addEventListener('click', closeDrawer);
document.getElementById('drawer-overlay').addEventListener('click', e => {
  if (e.target === document.getElementById('drawer-overlay')) closeDrawer();
});

// ============================================================
// DEPARTMENTS
// ============================================================

async function loadDepartments() {
  try {
    state.departments = await api('GET', '/departments');
    renderDepartments();
    document.getElementById('badge-departments').textContent = state.departments.length;
    document.getElementById('stat-departments').textContent = state.departments.length;
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderDepartments() {
  const tbody = document.getElementById('tbody-departments');
  if (!state.departments.length) {
    tbody.innerHTML = `<tr><td colspan="4" class="empty-row">No departments yet. Add one to get started!</td></tr>`;
    return;
  }
  tbody.innerHTML = state.departments.map(d => `
    <tr>
      <td class="id-cell" title="${escHtml(d.id)}">${shortId(d.id)}</td>
      <td><strong>${escHtml(d.name)}</strong></td>
      <td><span class="badge badge-purple">${escHtml(d.code)}</span></td>
      <td>
        <div class="action-buttons">
          <button class="btn btn-icon view" title="View Relations" onclick="viewDepartmentDetails('${d.id}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
          </button>
          <button class="btn btn-icon" title="Edit" onclick="editDepartment('${d.id}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/></svg>
          </button>
          <button class="btn btn-icon danger" title="Delete" onclick="deleteDepartment('${d.id}', '${escHtml(d.name)}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

document.getElementById('btn-add-department').addEventListener('click', () => {
  openModal('Add Department', `
    <div class="form-group">
      <label class="form-label">Name</label>
      <input class="form-input" id="f-dept-name" placeholder="e.g. Computer Science" />
    </div>
    <div class="form-group">
      <label class="form-label">Code</label>
      <input class="form-input" id="f-dept-code" placeholder="e.g. CS" maxlength="10" />
    </div>
  `, 'Create Department', async () => {
    const name = document.getElementById('f-dept-name').value.trim();
    const code = document.getElementById('f-dept-code').value.trim();
    if (!name || !code) throw new Error('Name and Code are required');
    await api('POST', '/departments', { name, code });
    await loadDepartments();
    toast('Department created!', 'success');
  });
});

window.editDepartment = function(id) {
  const dept = state.departments.find(d => d.id === id);
  if (!dept) return;
  openModal('Edit Department', `
    <div class="form-group">
      <label class="form-label">Name</label>
      <input class="form-input" id="f-dept-name" value="${escHtml(dept.name)}" />
    </div>
    <div class="form-group">
      <label class="form-label">Code</label>
      <input class="form-input" id="f-dept-code" value="${escHtml(dept.code)}" maxlength="10" />
    </div>
  `, 'Save Changes', async () => {
    const name = document.getElementById('f-dept-name').value.trim();
    const code = document.getElementById('f-dept-code').value.trim();
    const body = {};
    if (name) body.name = name;
    if (code) body.code = code;
    await api('PUT', `/departments/${id}`, body);
    await loadDepartments();
    toast('Department updated!', 'success');
  });
};

window.deleteDepartment = function(id, name) {
  openModal('Delete Department', `
    <p style="color:var(--text-secondary)">Are you sure you want to delete <strong style="color:var(--text-primary)">${escHtml(name)}</strong>?</p>
    <p style="color:var(--text-muted);margin-top:8px;font-size:12px;">Associated staff, student and book references will be updated.</p>
  `, 'Delete', async () => {
    await api('DELETE', `/departments/${id}`);
    await loadDepartments();
    toast('Department deleted', 'success');
  });
  document.getElementById('modal-submit').className = 'btn btn-danger';
};

window.viewDepartmentDetails = async function(id) {
  openDrawer('Department Details', `<div class="spinner"></div> Loading...`);
  try {
    const data = await api('GET', `/departments/${id}/details`);
    document.getElementById('drawer-body').innerHTML = `
      <div class="detail-section">
        <div class="detail-section-title">Basic Info</div>
        <div class="detail-field"><span class="detail-key">ID</span><span class="detail-value mono">${escHtml(data.id)}</span></div>
        <div class="detail-field"><span class="detail-key">Name</span><span class="detail-value">${escHtml(data.name)}</span></div>
        <div class="detail-field"><span class="detail-key">Code</span><span class="detail-value"><span class="badge badge-purple">${escHtml(data.code)}</span></span></div>
      </div>

      <div class="detail-section">
        <div class="detail-section-title">Staff (${data.staff.length})</div>
        <div class="detail-list">
          ${data.staff.length ? data.staff.map(s => `
            <div class="detail-list-item">
              <div class="item-title">${escHtml(s.name)}</div>
              <div class="item-sub">${escHtml(s.role)}</div>
            </div>`).join('') : '<p class="empty-hint">No staff in this department</p>'}
        </div>
      </div>

      <div class="detail-section">
        <div class="detail-section-title">Students (${data.students.length})</div>
        <div class="detail-list">
          ${data.students.length ? data.students.map(s => `
            <div class="detail-list-item">
              <div class="item-title">${escHtml(s.name)}</div>
              <div class="item-sub">Roll: ${escHtml(s.roll_no)}</div>
            </div>`).join('') : '<p class="empty-hint">No students in this department</p>'}
        </div>
      </div>

      <div class="detail-section">
        <div class="detail-section-title">Books (${data.books.length})</div>
        <div class="detail-list">
          ${data.books.length ? data.books.map(b => `
            <div class="detail-list-item">
              <div class="item-title">${escHtml(b.title)}</div>
              <div class="item-sub">ISBN: ${escHtml(b.isbn)}</div>
            </div>`).join('') : '<p class="empty-hint">No books in this department</p>'}
        </div>
      </div>
    `;
  } catch (err) {
    document.getElementById('drawer-body').innerHTML = `<p class="empty-hint" style="color:var(--red)">${err.message}</p>`;
  }
};

// ============================================================
// STAFF
// ============================================================

async function loadStaff() {
  try {
    state.staff = await api('GET', '/staff');
    renderStaff();
    document.getElementById('badge-staff').textContent = state.staff.length;
    document.getElementById('stat-staff').textContent = state.staff.length;
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderStaff() {
  const tbody = document.getElementById('tbody-staff');
  if (!state.staff.length) {
    tbody.innerHTML = `<tr><td colspan="5" class="empty-row">No staff members yet.</td></tr>`;
    return;
  }
  tbody.innerHTML = state.staff.map(s => `
    <tr>
      <td class="id-cell" title="${escHtml(s.id)}">${shortId(s.id)}</td>
      <td><strong>${escHtml(s.name)}</strong></td>
      <td><span class="badge badge-blue">${escHtml(s.role)}</span></td>
      <td>${getDeptName(s.department_id)}</td>
      <td>
        <div class="action-buttons">
          <button class="btn btn-icon view" title="View Relations" onclick="viewStaffDetails('${s.id}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
          </button>
          <button class="btn btn-icon" title="Edit" onclick="editStaff('${s.id}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/></svg>
          </button>
          <button class="btn btn-icon danger" title="Delete" onclick="deleteStaff('${s.id}', '${escHtml(s.name)}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

function deptOptions(selectedId = '') {
  return state.departments.map(d =>
    `<option value="${d.id}" ${d.id === selectedId ? 'selected' : ''}>${escHtml(d.name)} (${escHtml(d.code)})</option>`
  ).join('');
}

document.getElementById('btn-add-staff').addEventListener('click', () => {
  openModal('Add Staff Member', `
    <div class="form-group">
      <label class="form-label">Name</label>
      <input class="form-input" id="f-staff-name" placeholder="Full name" />
    </div>
    <div class="form-group">
      <label class="form-label">Role</label>
      <input class="form-input" id="f-staff-role" placeholder="e.g. Professor, Librarian, Admin" />
    </div>
    <div class="form-group">
      <label class="form-label">Department</label>
      <select class="form-select" id="f-staff-dept">
        <option value="">— Select Department —</option>
        ${deptOptions()}
      </select>
    </div>
  `, 'Create Staff', async () => {
    const name = document.getElementById('f-staff-name').value.trim();
    const role = document.getElementById('f-staff-role').value.trim();
    const department_id = document.getElementById('f-staff-dept').value;
    if (!name || !role || !department_id) throw new Error('All fields are required');
    await api('POST', '/staff', { name, role, department_id });
    await loadStaff();
    toast('Staff member added!', 'success');
  });
});

window.editStaff = function(id) {
  const s = state.staff.find(x => x.id === id);
  if (!s) return;
  openModal('Edit Staff Member', `
    <div class="form-group">
      <label class="form-label">Name</label>
      <input class="form-input" id="f-staff-name" value="${escHtml(s.name)}" />
    </div>
    <div class="form-group">
      <label class="form-label">Role</label>
      <input class="form-input" id="f-staff-role" value="${escHtml(s.role)}" />
    </div>
    <div class="form-group">
      <label class="form-label">Department</label>
      <select class="form-select" id="f-staff-dept">
        <option value="">— Select Department —</option>
        ${deptOptions(s.department_id)}
      </select>
    </div>
  `, 'Save Changes', async () => {
    const body = {};
    const name = document.getElementById('f-staff-name').value.trim();
    const role = document.getElementById('f-staff-role').value.trim();
    const department_id = document.getElementById('f-staff-dept').value;
    if (name) body.name = name;
    if (role) body.role = role;
    if (department_id) body.department_id = department_id;
    await api('PUT', `/staff/${id}`, body);
    await loadStaff();
    toast('Staff updated!', 'success');
  });
};

window.deleteStaff = function(id, name) {
  openModal('Delete Staff Member', `
    <p style="color:var(--text-secondary)">Delete <strong style="color:var(--text-primary)">${escHtml(name)}</strong>?</p>
  `, 'Delete', async () => {
    await api('DELETE', `/staff/${id}`);
    await loadStaff();
    toast('Staff member deleted', 'success');
  });
  document.getElementById('modal-submit').className = 'btn btn-danger';
};

window.viewStaffDetails = async function(id) {
  openDrawer('Staff Details', `<div class="spinner"></div> Loading...`);
  try {
    const data = await api('GET', `/staff/${id}/details`);
    document.getElementById('drawer-body').innerHTML = `
      <div class="detail-section">
        <div class="detail-section-title">Basic Info</div>
        <div class="detail-field"><span class="detail-key">ID</span><span class="detail-value mono">${escHtml(data.id)}</span></div>
        <div class="detail-field"><span class="detail-key">Name</span><span class="detail-value">${escHtml(data.name)}</span></div>
        <div class="detail-field"><span class="detail-key">Role</span><span class="detail-value"><span class="badge badge-blue">${escHtml(data.role)}</span></span></div>
      </div>
      <div class="detail-section">
        <div class="detail-section-title">Department (Many-to-One)</div>
        ${data.department ? `
          <div class="detail-field"><span class="detail-key">Name</span><span class="detail-value">${escHtml(data.department.name)}</span></div>
          <div class="detail-field"><span class="detail-key">Code</span><span class="detail-value"><span class="badge badge-purple">${escHtml(data.department.code)}</span></span></div>
        ` : '<p class="empty-hint">No department assigned</p>'}
      </div>
    `;
  } catch (err) {
    document.getElementById('drawer-body').innerHTML = `<p class="empty-hint" style="color:var(--red)">${err.message}</p>`;
  }
};

// ============================================================
// STUDENTS
// ============================================================

async function loadStudents() {
  try {
    state.students = await api('GET', '/students');
    renderStudents();
    document.getElementById('badge-students').textContent = state.students.length;
    document.getElementById('stat-students').textContent = state.students.length;
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderStudents() {
  const tbody = document.getElementById('tbody-students');
  if (!state.students.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-row">No students yet.</td></tr>`;
    return;
  }
  tbody.innerHTML = state.students.map(s => `
    <tr>
      <td class="id-cell" title="${escHtml(s.id)}">${shortId(s.id)}</td>
      <td><strong>${escHtml(s.name)}</strong></td>
      <td><span class="badge badge-green">${escHtml(s.roll_no)}</span></td>
      <td>${getDeptName(s.department_id)}</td>
      <td><span class="badge badge-orange">${s.borrowed_books ? s.borrowed_books.length : (s.borrowed_by ? s.borrowed_by.length : 0)} books</span></td>
      <td>
        <div class="action-buttons">
          <button class="btn btn-icon view" title="View Details" onclick="viewStudentDetails('${s.id}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
          </button>
          <button class="btn btn-icon" title="Edit" onclick="editStudent('${s.id}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/></svg>
          </button>
          <button class="btn btn-icon danger" title="Delete" onclick="deleteStudent('${s.id}', '${escHtml(s.name)}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

document.getElementById('btn-add-student').addEventListener('click', () => {
  openModal('Add Student', `
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Name</label>
        <input class="form-input" id="f-stud-name" placeholder="Full name" />
      </div>
      <div class="form-group">
        <label class="form-label">Roll No</label>
        <input class="form-input" id="f-stud-roll" placeholder="e.g. CS2024001" />
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Department</label>
      <select class="form-select" id="f-stud-dept">
        <option value="">— Select Department —</option>
        ${deptOptions()}
      </select>
    </div>
    <div style="margin-top:4px;padding-top:16px;border-top:1px solid var(--border)">
      <div style="font-size:12px;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;">Profile (Optional)</div>
      <div class="form-group">
        <label class="form-label">Address</label>
        <input class="form-input" id="f-stud-addr" placeholder="Home address" />
      </div>
      <div class="form-group">
        <label class="form-label">Phone Number</label>
        <input class="form-input" id="f-stud-phone" placeholder="e.g. 9876543210" />
      </div>
    </div>
  `, 'Create Student', async () => {
    const name = document.getElementById('f-stud-name').value.trim();
    const roll_no = document.getElementById('f-stud-roll').value.trim();
    const department_id = document.getElementById('f-stud-dept').value;
    const address = document.getElementById('f-stud-addr').value.trim();
    const phone_number = document.getElementById('f-stud-phone').value.trim();
    if (!name || !roll_no || !department_id) throw new Error('Name, Roll No, and Department are required');
    const payload = { name, roll_no, department_id };
    if (address && phone_number) payload.profile = { address, phone_number };
    await api('POST', '/students', payload);
    await loadStudents();
    toast('Student created!', 'success');
  });
});

window.editStudent = function(id) {
  const s = state.students.find(x => x.id === id);
  if (!s) return;
  openModal('Edit Student', `
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Name</label>
        <input class="form-input" id="f-stud-name" value="${escHtml(s.name)}" />
      </div>
      <div class="form-group">
        <label class="form-label">Roll No</label>
        <input class="form-input" id="f-stud-roll" value="${escHtml(s.roll_no)}" />
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Department</label>
      <select class="form-select" id="f-stud-dept">
        <option value="">— Select Department —</option>
        ${deptOptions(s.department_id)}
      </select>
    </div>
  `, 'Save Changes', async () => {
    const body = {};
    const name = document.getElementById('f-stud-name').value.trim();
    const roll_no = document.getElementById('f-stud-roll').value.trim();
    const department_id = document.getElementById('f-stud-dept').value;
    if (name) body.name = name;
    if (roll_no) body.roll_no = roll_no;
    if (department_id) body.department_id = department_id;
    await api('PUT', `/students/${id}`, body);
    await loadStudents();
    toast('Student updated!', 'success');
  });
};

window.deleteStudent = function(id, name) {
  openModal('Delete Student', `
    <p style="color:var(--text-secondary)">Delete student <strong style="color:var(--text-primary)">${escHtml(name)}</strong>?</p>
    <p style="color:var(--text-muted);margin-top:8px;font-size:12px;">Their profile and library records will also be deleted.</p>
  `, 'Delete', async () => {
    await api('DELETE', `/students/${id}`);
    await loadStudents();
    toast('Student deleted', 'success');
  });
  document.getElementById('modal-submit').className = 'btn btn-danger';
};

window.viewStudentDetails = async function(id) {
  openDrawer('Student Details', `<div class="spinner"></div> Loading...`);
  try {
    const data = await api('GET', `/students/${id}/details`);
    document.getElementById('drawer-body').innerHTML = `
      <div class="detail-section">
        <div class="detail-section-title">Basic Info</div>
        <div class="detail-field"><span class="detail-key">ID</span><span class="detail-value mono">${escHtml(data.id)}</span></div>
        <div class="detail-field"><span class="detail-key">Name</span><span class="detail-value">${escHtml(data.name)}</span></div>
        <div class="detail-field"><span class="detail-key">Roll No</span><span class="detail-value"><span class="badge badge-green">${escHtml(data.roll_no)}</span></span></div>
      </div>

      <div class="detail-section">
        <div class="detail-section-title">Department (Many-to-One)</div>
        ${data.department ? `
          <div class="detail-field"><span class="detail-key">Name</span><span class="detail-value">${escHtml(data.department.name)}</span></div>
          <div class="detail-field"><span class="detail-key">Code</span><span class="detail-value"><span class="badge badge-purple">${escHtml(data.department.code)}</span></span></div>
        ` : '<p class="empty-hint">No department</p>'}
      </div>

      <div class="detail-section">
        <div class="detail-section-title">Profile (One-to-One)</div>
        ${data.profile ? `
          <div class="detail-field"><span class="detail-key">Address</span><span class="detail-value">${escHtml(data.profile.address)}</span></div>
          <div class="detail-field"><span class="detail-key">Phone</span><span class="detail-value">${escHtml(data.profile.phone_number)}</span></div>
        ` : '<p class="empty-hint">No profile set</p>'}
      </div>

      <div class="detail-section">
        <div class="detail-section-title">Borrowed Books (${(data.borrowed_books || []).length}) — Many-to-Many</div>
        <div class="detail-list">
          ${(data.borrowed_books || []).length ? data.borrowed_books.map(b => `
            <div class="detail-list-item">
              <div class="item-title">${escHtml(b.title)}</div>
              <div class="item-sub">ISBN: ${escHtml(b.isbn)}</div>
            </div>`).join('') : '<p class="empty-hint">No books borrowed</p>'}
        </div>
      </div>
    `;
  } catch (err) {
    document.getElementById('drawer-body').innerHTML = `<p class="empty-hint" style="color:var(--red)">${err.message}</p>`;
  }
};

// ============================================================
// BOOKS
// ============================================================

async function loadBooks() {
  try {
    state.books = await api('GET', '/books');
    renderBooks();
    document.getElementById('badge-books').textContent = state.books.length;
    document.getElementById('stat-books').textContent = state.books.length;
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderBooks() {
  const tbody = document.getElementById('tbody-books');
  if (!state.books.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-row">No books yet.</td></tr>`;
    return;
  }
  tbody.innerHTML = state.books.map(b => `
    <tr>
      <td class="id-cell" title="${escHtml(b.id)}">${shortId(b.id)}</td>
      <td><strong>${escHtml(b.title)}</strong></td>
      <td><span style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text-muted)">${escHtml(b.isbn)}</span></td>
      <td>${getDeptName(b.department_id)}</td>
      <td><span class="badge badge-orange">${(b.borrowed_by || []).length} borrowers</span></td>
      <td>
        <div class="action-buttons">
          <button class="btn btn-icon view" title="View Details" onclick="viewBookDetails('${b.id}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
          </button>
          <button class="btn btn-icon" title="Edit" onclick="editBook('${b.id}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/></svg>
          </button>
          <button class="btn btn-icon danger" title="Delete" onclick="deleteBook('${b.id}', '${escHtml(b.title)}')">
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

document.getElementById('btn-add-book').addEventListener('click', () => {
  openModal('Add Book', `
    <div class="form-group">
      <label class="form-label">Title</label>
      <input class="form-input" id="f-book-title" placeholder="Book title" />
    </div>
    <div class="form-group">
      <label class="form-label">ISBN</label>
      <input class="form-input" id="f-book-isbn" placeholder="e.g. 978-3-16-148410-0" />
      <div class="form-hint">10–17 characters</div>
    </div>
    <div class="form-group">
      <label class="form-label">Department</label>
      <select class="form-select" id="f-book-dept">
        <option value="">— Select Department —</option>
        ${deptOptions()}
      </select>
    </div>
  `, 'Add Book', async () => {
    const title = document.getElementById('f-book-title').value.trim();
    const isbn = document.getElementById('f-book-isbn').value.trim();
    const department_id = document.getElementById('f-book-dept').value;
    if (!title || !isbn || !department_id) throw new Error('All fields are required');
    await api('POST', '/books', { title, isbn, department_id });
    await loadBooks();
    toast('Book added!', 'success');
  });
});

window.editBook = function(id) {
  const b = state.books.find(x => x.id === id);
  if (!b) return;
  openModal('Edit Book', `
    <div class="form-group">
      <label class="form-label">Title</label>
      <input class="form-input" id="f-book-title" value="${escHtml(b.title)}" />
    </div>
    <div class="form-group">
      <label class="form-label">ISBN</label>
      <input class="form-input" id="f-book-isbn" value="${escHtml(b.isbn)}" />
    </div>
    <div class="form-group">
      <label class="form-label">Department</label>
      <select class="form-select" id="f-book-dept">
        <option value="">— Select Department —</option>
        ${deptOptions(b.department_id)}
      </select>
    </div>
  `, 'Save Changes', async () => {
    const body = {};
    const title = document.getElementById('f-book-title').value.trim();
    const isbn = document.getElementById('f-book-isbn').value.trim();
    const department_id = document.getElementById('f-book-dept').value;
    if (title) body.title = title;
    if (isbn) body.isbn = isbn;
    if (department_id) body.department_id = department_id;
    await api('PUT', `/books/${id}`, body);
    await loadBooks();
    toast('Book updated!', 'success');
  });
};

window.deleteBook = function(id, title) {
  openModal('Delete Book', `
    <p style="color:var(--text-secondary)">Delete <strong style="color:var(--text-primary)">${escHtml(title)}</strong>?</p>
  `, 'Delete', async () => {
    await api('DELETE', `/books/${id}`);
    await loadBooks();
    toast('Book deleted', 'success');
  });
  document.getElementById('modal-submit').className = 'btn btn-danger';
};

window.viewBookDetails = async function(id) {
  openDrawer('Book Details', `<div class="spinner"></div> Loading...`);
  try {
    const data = await api('GET', `/books/${id}/details`);
    document.getElementById('drawer-body').innerHTML = `
      <div class="detail-section">
        <div class="detail-section-title">Basic Info</div>
        <div class="detail-field"><span class="detail-key">ID</span><span class="detail-value mono">${escHtml(data.id)}</span></div>
        <div class="detail-field"><span class="detail-key">Title</span><span class="detail-value">${escHtml(data.title)}</span></div>
        <div class="detail-field"><span class="detail-key">ISBN</span><span class="detail-value mono">${escHtml(data.isbn)}</span></div>
      </div>

      <div class="detail-section">
        <div class="detail-section-title">Department (Many-to-One)</div>
        ${data.department ? `
          <div class="detail-field"><span class="detail-key">Name</span><span class="detail-value">${escHtml(data.department.name)}</span></div>
          <div class="detail-field"><span class="detail-key">Code</span><span class="detail-value"><span class="badge badge-purple">${escHtml(data.department.code)}</span></span></div>
        ` : '<p class="empty-hint">No department</p>'}
      </div>

      <div class="detail-section">
        <div class="detail-section-title">Borrowed By (${(data.borrowed_by_students || []).length}) — Many-to-Many</div>
        <div class="detail-list">
          ${(data.borrowed_by_students || []).length ? data.borrowed_by_students.map(s => `
            <div class="detail-list-item">
              <div class="item-title">${escHtml(s.name)}</div>
              <div class="item-sub">Roll: ${escHtml(s.roll_no)}</div>
            </div>`).join('') : '<p class="empty-hint">Not borrowed by anyone yet</p>'}
        </div>
      </div>
    `;
  } catch (err) {
    document.getElementById('drawer-body').innerHTML = `<p class="empty-hint" style="color:var(--red)">${err.message}</p>`;
  }
};

// ============================================================
// BORROWING VIEW
// ============================================================

function refreshBorrowingSelects() {
  const bookOptions = state.books.map(b =>
    `<option value="${b.id}">${escHtml(b.title)}</option>`
  ).join('');
  const studentOptions = state.students.map(s =>
    `<option value="${s.id}">${escHtml(s.name)} (${escHtml(s.roll_no)})</option>`
  ).join('');

  ['borrow-book-select', 'return-book-select'].forEach(id => {
    const el = document.getElementById(id);
    el.innerHTML = `<option value="">— Choose a book —</option>${bookOptions}`;
  });
  ['borrow-student-select', 'return-student-select'].forEach(id => {
    const el = document.getElementById(id);
    el.innerHTML = `<option value="">— Choose a student —</option>${studentOptions}`;
  });
}

function addBorrowLog(type, bookTitle, studentName) {
  const list = document.getElementById('borrow-log-list');
  const emptyHint = list.querySelector('.empty-hint');
  if (emptyHint) emptyHint.remove();

  const now = new Date();
  const timeStr = now.toLocaleTimeString();
  const entry = document.createElement('div');
  entry.className = 'borrow-log-entry';
  entry.innerHTML = `
    <div class="log-icon ${type}">${type === 'borrow' ? '📖' : '↩️'}</div>
    <div class="log-content">
      <div class="log-title">${type === 'borrow' ? 'Borrowed' : 'Returned'}: ${escHtml(bookTitle)}</div>
      <div class="log-sub">by ${escHtml(studentName)}</div>
    </div>
    <div class="log-time">${timeStr}</div>
  `;
  list.insertBefore(entry, list.firstChild);
}

document.getElementById('btn-borrow').addEventListener('click', async () => {
  const bookId = document.getElementById('borrow-book-select').value;
  const studentId = document.getElementById('borrow-student-select').value;
  if (!bookId || !studentId) { toast('Please select both a book and a student', 'error'); return; }
  const btn = document.getElementById('btn-borrow');
  btn.disabled = true;
  try {
    await api('POST', `/books/${bookId}/borrow/${studentId}`);
    const book = state.books.find(b => b.id === bookId);
    const student = state.students.find(s => s.id === studentId);
    addBorrowLog('borrow', book?.title || bookId, student?.name || studentId);
    await loadBooks();
    await loadStudents();
    refreshBorrowingSelects();
    toast('Book borrowed successfully!', 'success');
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    btn.disabled = false;
  }
});

document.getElementById('btn-return').addEventListener('click', async () => {
  const bookId = document.getElementById('return-book-select').value;
  const studentId = document.getElementById('return-student-select').value;
  if (!bookId || !studentId) { toast('Please select both a book and a student', 'error'); return; }
  const btn = document.getElementById('btn-return');
  btn.disabled = true;
  try {
    await api('POST', `/books/${bookId}/return/${studentId}`);
    const book = state.books.find(b => b.id === bookId);
    const student = state.students.find(s => s.id === studentId);
    addBorrowLog('return', book?.title || bookId, student?.name || studentId);
    await loadBooks();
    await loadStudents();
    refreshBorrowingSelects();
    toast('Book returned successfully!', 'success');
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    btn.disabled = false;
  }
});

// ============================================================
// INIT
// ============================================================

async function init() {
  await checkDbStatus();
  await loadAllData();
}

init();
