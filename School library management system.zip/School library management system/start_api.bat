@echo off
echo ===================================================
echo   STARTING SCHOOL LIBRARY MANAGEMENT FASTAPI SERVER
echo ===================================================
echo.
echo 1. Activating virtual environment...
call .venv\Scripts\activate.bat
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to activate virtual environment.
    pause
    exit /b %ERRORLEVEL%
)

echo 2. Running FastAPI server on http://localhost:8000 ...
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to run uvicorn server.
    pause
)
