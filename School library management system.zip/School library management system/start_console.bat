@echo off
echo ===================================================
echo   STARTING SCHOOL LIBRARY MANAGEMENT CONSOLE APP
echo ===================================================
echo.
echo 1. Activating virtual environment...
call .venv\Scripts\activate.bat
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to activate virtual environment.
    pause
    exit /b %ERRORLEVEL%
)

echo 2. Launching Interactive Console Application...
python console_app.py
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to run console_app.py
    pause
)
