import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import app.crud as crud
from app.database import get_db_info

def run_tests():
    print("Starting CRUD tests...")
    info = get_db_info()
    print(f"Database Mode: {info['db_type']}")
    
    # 1. Create Department
    dept = crud.create_department("Computer Science", "CS")
    assert dept["id"] is not None
    assert dept["name"] == "Computer Science"
    assert dept["code"] == "CS"
    print("[OK] Department creation passed.")

    # 2. Create Staff
    staff = crud.create_staff("Dr. Ada Lovelace", "Associate Professor", dept["id"])
    assert staff["id"] is not None
    assert staff["name"] == "Dr. Ada Lovelace"
    assert staff["department_id"] == dept["id"]
    print("[OK] Staff creation passed.")

    # 3. Create Student with Profile
    student = crud.create_student(
        "Bob Smith", "CS-101", dept["id"],
        {"address": "789 Algorithm Ave", "phone_number": "123-456-7890"}
    )
    assert student["id"] is not None
    assert student["name"] == "Bob Smith"
    print("[OK] Student with Profile creation passed.")

    # 4. Create Book
    book = crud.create_book("Structure and Interpretation of Computer Programs", "978-0262510875", dept["id"])
    assert book["id"] is not None
    assert book["title"] == "Structure and Interpretation of Computer Programs"
    print("[OK] Book creation passed.")

    # 5. Borrow Book (Many-to-Many relationship)
    updated_book = crud.borrow_book(book["id"], student["id"])
    assert student["id"] in updated_book["borrowed_by"]
    print("[OK] Book borrowing passed.")

    # 6. Verify joined student details
    stud_details = crud.get_student_details(student["id"])
    assert stud_details["department"]["name"] == "Computer Science"
    assert stud_details["profile"]["address"] == "789 Algorithm Ave"
    assert len(stud_details["borrowed_books"]) == 1
    assert stud_details["borrowed_books"][0]["title"] == "Structure and Interpretation of Computer Programs"
    print("[OK] Student details retrieval ($lookup join) passed.")

    # 7. Update Student
    updated_stud = crud.update_student(student["id"], {"name": "Bob J. Smith", "profile": {"phone_number": "999-999-9999"}})
    assert updated_stud["name"] == "Bob J. Smith"
    assert updated_stud["profile"]["phone_number"] == "999-999-9999"
    print("[OK] Student & Profile update passed.")

    # 8. Return Book
    returned_book = crud.return_book(book["id"], student["id"])
    assert student["id"] not in returned_book["borrowed_by"]
    print("[OK] Book returning passed.")

    # 9. Delete Student and Verify Cascade
    delete_result = crud.delete_student(student["id"])
    assert delete_result is True
    assert crud.get_student(student["id"]) is None
    print("[OK] Student deletion & profile cleanup passed.")

    print("\nALL TESTS COMPLETED SUCCESSFULLY!")

if __name__ == "__main__":
    run_tests()
